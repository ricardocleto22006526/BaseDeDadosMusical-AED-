package pt.ulusofona.aed.deisiRockstar2021;

public class ArtistsInfo {
    String nome;
    int quantidadeMusicas;

    public ArtistsInfo() {
    }

    public ArtistsInfo(String nome, int quantidadeMusicas) {
        this.nome = nome;
        this.quantidadeMusicas = quantidadeMusicas;
    }
}
