package pt.ulusofona.aed.deisiRockstar2021;

public class SongsInfo {
    String id;
    int ano;

    public SongsInfo() {
    }

    public SongsInfo(String id, int ano) {
        this.id = id;
        this.ano = ano;
    }
}
